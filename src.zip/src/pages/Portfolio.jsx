import { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import api from "../api/api";

function Portfolio() {
  const [holdings, setHoldings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPortfolio();
  }, []);

  const loadPortfolio = async () => {
    try {
      const res = await api.get("/holdings/");
      setHoldings(res.data);
    } catch (err) {
      console.error("Portfolio Error:", err);
    } finally {
      setLoading(false);
    }
  };

  const totalInvested = holdings.reduce(
    (sum, item) => sum + item.quantity * item.avg_price,
    0
  );

  const totalValue = holdings.reduce(
    (sum, item) => sum + item.quantity * item.current_price,
    0
  );

  const totalPnL = totalValue - totalInvested;

  return (
  <div className="dashboard-layout">
    <Sidebar />

    <div className="dashboard-main">
      <div className="dashboard-content">

        <h1>Portfolio</h1>

        {/* portfolio cards */}

            {/* Summary Cards */}
        <div className="dashboard-cards">

          <div className="stat-card">
            <h4>Total Holdings</h4>
            <h2>{holdings.length}</h2>
          </div>

          <div className="stat-card">
            <h4>Invested Value</h4>
            <h2>₹{totalInvested.toLocaleString()}</h2>
          </div>

          <div className="stat-card">
            <h4>Current Value</h4>
            <h2>₹{totalValue.toLocaleString()}</h2>
          </div>

          <div className="stat-card">
            <h4>Total P&L</h4>
            <h2
              style={{
                color: totalPnL >= 0 ? "#16a34a" : "#dc2626",
              }}
            >
              ₹{totalPnL.toLocaleString()}
            </h2>
          </div>

        </div>

        {/* Holdings Table */}
        <div className="dashboard-card">

          <h2>My Holdings</h2>

          {loading ? (
            <p>Loading...</p>
          ) : holdings.length === 0 ? (
            <p>No holdings found.</p>
          ) : (
            <table className="portfolio-table">

              <thead>
                <tr>
                  <th>Symbol</th>
                  <th>Quantity</th>
                  <th>Avg Price</th>
                  <th>Current Price</th>
                  <th>Invested</th>
                  <th>Current Value</th>
                  <th>P&L</th>
                </tr>
              </thead>

              <tbody>

                {holdings.map((item) => {
                  const invested =
                    item.quantity * item.avg_price;

                  const current =
                    item.quantity * item.current_price;

                  const pnl = current - invested;

                  return (
                    <tr key={item.id}>
                      <td>{item.symbol}</td>

                      <td>{item.quantity}</td>

                      <td>
                        ₹{item.avg_price.toLocaleString()}
                      </td>

                      <td>
                        ₹{item.current_price.toLocaleString()}
                      </td>

                      <td>
                        ₹{invested.toLocaleString()}
                      </td>

                      <td>
                        ₹{current.toLocaleString()}
                      </td>

                      <td
                        style={{
                          color:
                            pnl >= 0
                              ? "#16a34a"
                              : "#dc2626",
                          fontWeight: "600",
                        }}
                      >
                        ₹{pnl.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}

              </tbody>

            </table>
          )}

        </div>

      </div>
    </div>
  </div>
  );
}

export default Portfolio;