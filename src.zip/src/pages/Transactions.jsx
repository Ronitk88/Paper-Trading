import { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import api from "../api/api";

function Transactions() {
const [transactions, setTransactions] = useState([]);
const [loading, setLoading] = useState(true);

useEffect(() => {
loadTransactions();
}, []);

const loadTransactions = async () => {
try {
const res = await api.get("/transactions/");
setTransactions(res.data);
} catch (err) {
console.error("Transaction Error:", err);
} finally {
setLoading(false);
}
};

return ( <div className="dashboard-layout"> <Sidebar />


  <div className="dashboard-main">
    <div className="dashboard-content">

      <h1>Transactions</h1>

<div className="dashboard-cards">
  <div className="stat-card">
    <h4>Total Transactions</h4>
    <h2>{transactions.length}</h2>
  </div>
</div>

<div className="dashboard-card">
        {loading ? (
          <p>Loading...</p>
        ) : transactions.length === 0 ? (
          <p>No transactions found.</p>
        ) : (
          <table>
            <thead>
  <tr>
    <th>Symbol</th>
    <th>Type</th>
    <th>Quantity</th>
    <th>Price</th>
    <th>Date</th>
  </tr>
</thead>

           <tbody>
  {transactions.map((tx) => (
    <tr key={tx.id}>
      <td>{tx.symbol}</td>

      <td
        className={
          tx.transaction_type === "BUY"
            ? "green"
            : "red"
        }
      >
        {tx.transaction_type}
      </td>

      <td>{tx.quantity}</td>

      <td>
        ₹{Number(tx.price).toLocaleString()}
      </td>

      <td>
        {new Date(tx.created_at).toLocaleDateString("en-IN")}
      </td>
    </tr>
  ))}
</tbody>
          </table>
        )}
      </div>

    </div>
  </div>
</div>


);
}

export default Transactions;
