import { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import api from "../api/api";

function Watchlist() {

  const [stocks, setStocks] = useState([]);

  useEffect(() => {
    loadWatchlist();
  }, []);

  const loadWatchlist = async () => {
    try {
      const res = await api.get("/watchlist/");
      setStocks(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="dashboard-layout">

      <Sidebar />

      <div className="dashboard-main">
        <div className="dashboard-content">

          <h1>Watchlist</h1>

          <div className="table-card">
            <h2>My Watchlist</h2>

            {stocks.length === 0 ? (
              <div className="empty-state">
                <h3>No stocks in watchlist</h3>
                <p>
                  Add stocks from the Stocks page to track them here.
                </p>
              </div>
            ) : (
              <table>
                <tbody>
                  {stocks.map((s) => (
                    <tr key={s.id}>
                      <td>{s.symbol}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          </div>

        </div>
      </div>
  );
}

export default Watchlist;