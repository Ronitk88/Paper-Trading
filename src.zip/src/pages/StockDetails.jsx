import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../api/api";
import TradingViewChart from "../components/TradingViewChart";

function StockDetails() {
  const { symbol } = useParams();

  const [stock, setStock] = useState(null);
  const [ltp, setLtp] = useState(null);

  useEffect(() => {
    loadStock();
  }, [symbol]);

  const loadStock = async () => {
    try {
      const res = await api.get("/stocks/search", {
        params: {
          q: symbol,
        },
      });

      if (!res.data || res.data.length === 0) {
        return;
      }

      const s = res.data[0];

      console.log("Stock object:", s);
      console.log("Stock symbol:", s.symbol);

      setStock(s);

      const ltpRes = await api.get("/market/ltp", {
        params: {
          exchange: s.exchange,
          tradingsymbol: s.symbol,
          symboltoken: s.token,
        },
      });

      setLtp(ltpRes.data?.data?.ltp ?? null);
    } catch (err) {
      console.error(err);
    }
  };

  if (!stock) {
    return <h2 style={{ padding: "30px" }}>Loading...</h2>;
  }

  return (
    <div style={{ padding: "30px" }}>
      <h1>{stock.name}</h1>

      <h2 style={{ color: "#16a34a" }}>
        {ltp !== null ? `₹${ltp}` : "Loading LTP..."}
      </h2>

      <div
        style={{
          width: "100%",
          height: "650px",
          marginTop: "20px",
          marginBottom: "30px",
        }}
      >
        <TradingViewChart symbol={stock.symbol} />
      </div>

      <div
        style={{
          display: "flex",
          gap: "15px",
          marginBottom: "30px",
        }}
      >
        <button className="buy-btn">Buy</button>
        <button className="watch-btn">Sell</button>
        <button className="watch-btn">+ Watchlist</button>
      </div>

      <div
        style={{
          border: "1px solid #ddd",
          borderRadius: "10px",
          padding: "20px",
        }}
      >
        <h3>Company Information</h3>

        <p>
          <strong>Symbol:</strong> {stock.symbol}
        </p>

        <p>
          <strong>Exchange:</strong> {stock.exchange}
        </p>

        <p>
          <strong>Token:</strong> {stock.token}
        </p>
      </div>
    </div>
  );
}

export default StockDetails;