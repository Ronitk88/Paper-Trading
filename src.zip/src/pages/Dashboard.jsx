import { useEffect, useState } from "react";
import API from "../api/api";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import StatsCards from "../components/StatsCards";
import PortfolioChart from "../components/PortfolioChart";
import HoldingsTable from "../components/HoldingsTable";
import TransactionsTable from "../components/TransactionsTable";
import MarketOverview from "../components/MarketOverview";
import TopGainers from "../components/TopGainers";
import TopLosers from "../components/TopLosers";

import "../styles/dashboard.css";

function Dashboard() { 
const [portfolio, setPortfolio] = useState(null);
const [holdings, setHoldings] = useState([]);
const [transactions, setTransactions] = useState([]);

const username =
localStorage.getItem("username") || "Trader";

useEffect(() => {
loadDashboard();
}, []);

const loadDashboard = async () => {
try {
const [portfolioRes, holdingsRes, transactionsRes] =
await Promise.all([
API.get("/portfolio"),
API.get("/holdings"),
API.get("/transactions"),
]);

  console.log("Portfolio:", portfolioRes.data);
  console.log("Holdings:", holdingsRes.data);
  console.log("Transactions:", transactionsRes.data);

  setPortfolio(portfolioRes.data);
  setHoldings(holdingsRes.data || []);
  setTransactions(transactionsRes.data || []);
} catch (error) {
  console.error("Dashboard Error:", error);
}


};

const hour = new Date().getHours();

let greeting = "Good Morning";

if (hour >= 12) greeting = "Good Afternoon";
if (hour >= 17) greeting = "Good Evening";

return ( <div className="dashboard-layout"> <Sidebar />


  <div className="dashboard-main">
    <Navbar />

    <div className="dashboard-content">

      <div className="welcome-section">
        <h1>
          {greeting}, <span>{username}</span> 👋
        </h1>

        <p>
          Here's what's happening with your portfolio today.
        </p>
      </div>

      <StatsCards portfolio={portfolio} holdings={holdings}/>

      <div className="middle-grid">
        <div className="chart-section">
          <PortfolioChart portfolio={portfolio} />
        </div>

        <div className="right-panel">
          <MarketOverview />
        </div>
      </div>

      <div className="bottom-grid">
        <div className="tables-section">
          <HoldingsTable holdings={holdings} />

          <TransactionsTable
            transactions={transactions}
          />
        </div>

        <div className="stocks-panel">
          <TopGainers />
          <TopLosers />
        </div>
      </div>

     <div className="footer-note">
  This is a paper trading platform.
  All trades are simulated and no real money is involved.
</div>

</div>
</div>
</div>
);
}

export default Dashboard;
