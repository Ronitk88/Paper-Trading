import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import api from "../api/api";

function Stocks() {
  const navigate = useNavigate();

  const [stocks, setStocks] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    loadStocks();
  }, []);

  // Load LTPs in parallel
  const attachPrices = async (stockList) => {
    const updatedStocks = await Promise.all(
      stockList.map(async (stock) => {
        try {
          const res = await api.get("/market/ltp", {
            params: {
              exchange: stock.exchange,
              tradingsymbol: stock.symbol,
              symboltoken: stock.token,
            },
          });

          return {
            ...stock,
            ltp: res.data?.data?.ltp ?? null,
          };
        } catch (err) {
          console.error("LTP failed:", stock.symbol);

          return {
            ...stock,
            ltp: null,
          };
        }
      })
    );

    return updatedStocks;
  };

  // Initial load
  const loadStocks = async () => {
    try {
      const res = await api.get("/stocks", {
        params: {
          limit: 50,
          offset: 0,
        },
      });

      const stocksWithPrices = await attachPrices(res.data);

      setStocks(stocksWithPrices);
    } catch (err) {
      console.error(err);
    }
  };

  // Search
  const handleSearch = async (value) => {
    setSearch(value);

    try {
      if (!value.trim()) {
        loadStocks();
        return;
      }

      const res = await api.get("/stocks/search", {
        params: {
          q: value,
        },
      });

      const stocksWithPrices = await attachPrices(res.data);

      setStocks(stocksWithPrices);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="dashboard-layout">
      <Sidebar />

      <div className="dashboard-main">
        <Navbar />

        <div className="dashboard-content">
          <h1>Stocks Market</h1>

          <input
            type="text"
            placeholder="Search NSE/BSE Stock..."
            value={search}
            onChange={(e) => handleSearch(e.target.value)}
            style={{
              width: "100%",
              padding: "12px",
              margin: "20px 0",
              borderRadius: "10px",
              border: "1px solid #ccc",
              fontSize: "16px",
            }}
          />

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fill, minmax(280px, 1fr))",
              gap: "20px",
            }}
          >
            {stocks.map((stock) => (
              <div
                key={stock.id}
                className="stat-card"
                style={{
                  cursor: "pointer",
                }}
                onClick={() =>
                  navigate(`/stocks/${stock.symbol}`)
                }
              >
                <h2>{stock.symbol}</h2>

                <p>{stock.name}</p>

                <p
                  style={{
                    marginTop: "10px",
                    color: "#666",
                  }}
                >
                  Exchange: {stock.exchange}
                </p>

                <p
                  style={{
                    color: "#888",
                    fontSize: "14px",
                  }}
                >
                  Token: {stock.token}
                </p>

                <h3
                  style={{
                    marginTop: "15px",
                    color: "#16a34a",
                  }}
                >
                  {stock.ltp !== null
                    ? `₹${stock.ltp}`
                    : "Loading..."}
                </h3>

                <div
                  style={{
                    display: "flex",
                    gap: "10px",
                    marginTop: "20px",
                  }}
                >
                  <button
                    className="watch-btn"
                    onClick={(e) => e.stopPropagation()}
                  >
                    + Watchlist
                  </button>

                  <button
                    className="buy-btn"
                    onClick={(e) => e.stopPropagation()}
                  >
                    Buy
                  </button>
                </div>
              </div>
            ))}
          </div>

          {stocks.length === 0 && (
            <p style={{ marginTop: "20px" }}>
              No stocks found.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default Stocks;