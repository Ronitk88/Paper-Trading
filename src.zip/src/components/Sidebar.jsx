import {
 FaChartPie,
 FaChartLine,
 FaStar,
 FaBriefcase,
 FaReceipt,
 FaClipboardList,
 FaChartBar,
 FaCog
 
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";


function Sidebar() {
  const navigate = useNavigate();

  return (
    <div className="sidebar">

      <div>
        <h2 className="logo">
📈 Paper Trading
</h2>

        <ul>
<li onClick={() => navigate("/dashboard")}>
  <FaChartPie /> Dashboard
</li>

<li onClick={() => navigate("/stocks")}>
  <FaChartLine /> Stocks
</li>
 <li onClick={() => navigate("/watchlist")}>
  <FaStar /> Watchlist
</li>
<li onClick={() => navigate("/portfolio")}>
  <FaBriefcase /> Portfolio
</li>
 <li onClick={() => navigate("/transactions")}>
  <FaReceipt /> Transactions
</li>
  <li><FaClipboardList /> Orders</li>
  <li><FaChartBar /> Analytics</li>
  <li><FaCog /> Settings</li>
</ul>
      </div>

      <div className="sidebar-footer">
        <div className="cash-box">
          <p>Virtual Cash</p>
          <h3>₹10,00,000</h3>

          <p>Buying Power</p>
          <h4>₹10,00,000</h4>
        </div>

        <button className="logout-btn">
          Logout
        </button>
      </div>

    </div>
  );
}



export default Sidebar;