import {
 FaBell,
 FaSearch
} from "react-icons/fa";
function Navbar() {
  const username =
    localStorage.getItem("username") || "Trader";

  return (
    <div className="navbar">

      <div className="search-box">
        <input
          type="text"
          placeholder="Search stocks, e.g. TCS, INFY, RELIANCE..."
        />
      </div>

      <div className="market-strip">
        <span>NIFTY 50 ▲ 0.62%</span>
        <span>SENSEX ▲ 0.58%</span>
      </div>

      <div className="user-box">
        <div className="avatar">
          {username.charAt(0).toUpperCase()}
        </div>

        <span>{username}</span>
      </div>

    </div>
  );
}

export default Navbar;