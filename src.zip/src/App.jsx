
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Stocks from "./pages/Stocks";
import Portfolio from "./pages/Portfolio";
import Transactions from "./pages/Transactions";
import Watchlist from "./pages/Watchlist";
import StockDetails from "./pages/StockDetails";

function App() {
  const token = localStorage.getItem("token");

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={token ? <Navigate to="/dashboard" /> : <Login />}
        />

        <Route
          path="/dashboard"
          element={token ? <Dashboard /> : <Navigate to="/" />}
        />

        <Route
          path="/stocks"
          element={token ? <Stocks /> : <Navigate to="/" />}
        />

        <Route
          path="/stocks/:symbol"
          element={token ? <StockDetails /> : <Navigate to="/" />}
        />

        <Route
          path="/watchlist"
          element={token ? <Watchlist /> : <Navigate to="/" />}
        />

        <Route
          path="/portfolio"
          element={token ? <Portfolio /> : <Navigate to="/" />}
        />

        <Route
          path="/transactions"
          element={token ? <Transactions /> : <Navigate to="/" />}
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
