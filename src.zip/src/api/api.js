import axios from "axios";

const API = axios.create({
  baseURL: "http://127.0.0.1:8000",
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");

  console.log(
    "TOKEN FROM STORAGE:",
    token
  );

  if (token) {
    config.headers.Authorization =
      `Bearer ${token}`;
  }

  return config;
});

import api from "./api";

export const searchStocks = (query) => {
  return api.get(`/stocks/search?q=${encodeURIComponent(query)}`);
};

export const getStocks = () => {
  return api.get("/stocks");
};

export default API;

